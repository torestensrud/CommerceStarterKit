require({cache:{
'url:epi-ecf-ui/widget/templates/CampaignItemList.html':"﻿<div>\n    <div class=\"epi-campaignHeading\">\n        <div class=\"epi-iconPrice epi-icon--medium epi-icon--inverted dijitInline\"></div>\n        <div class=\"epi-campaignDetails dijitInline\">\n            <h2 data-dojo-attach-point=\"campaignNameNode\"></h2>\n            <span data-dojo-attach-point=\"campaignDescriptionNode\"></span>\n        </div>\n    </div>\n    <div class=\"epi-campaignList\" data-dojo-attach-point=\"gridNode\"></div>\n</div>\n"}});
﻿define("epi-ecf-ui/widget/CampaignItemList", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/when",
// dijit
    "dijit/_TemplatedMixin",
// epi
    "epi-cms/widget/_GridWidgetBase",
    "epi/shell/TypeDescriptorManager",
// commerce
    "./viewmodel/CampaignItemListModel",
    "../MarketingUtils",
    "dojo/text!./templates/CampaignItemList.html",
// resources
    "epi/i18n!epi/nls/commerce.widget.campaignitemlist"
],
function (
// dojo
    declare,
    lang,
    aspect,
    domClass,
    when,
//dijit
    _TemplatedMixin,
// epi
    _GridWidgetBase,
    TypeDescriptorManager,
// commerce
    CampaignItemListModel,
    MarketingUtils,
    templateString,
// resources
    resources
) {
    return declare([_GridWidgetBase], {

        storeKeyName: "epi.cms.content.light",

        typeIdentifiers: [
            MarketingUtils.contentTypeIdentifier.salesCampaign,
            MarketingUtils.contentTypeIdentifier.promotionData
        ],

        postMixInProperties: function () {
            this.inherited(arguments);
            this.model = new CampaignItemListModel();
        },

        buildRendering: function () {
            // summary:
            //		Construct the UI for this widget with this.domNode initialized as a dgrid.
            // tags:
            //		protected

            this.inherited(arguments);

            this._modifyStoreToHandleDgridTree();

            var gridSettings = lang.mixin(this.defaultGridMixin, {
                className: "epi-card-grid",
                columns: this.model.createGridColumns(),
                store: this.store,
                selectionMode: "none",
                dndDisabled: true,
                showHeader: false,
                noDataMessage: resources.emptycampaign,
                renderArray: function(){
                    return when(this.inherited(arguments), lang.hitch(this, function(trs){
                        //After calling the inherited renderArray function we clear the noDataNode.
                        //This forces the grid to create a new node every time a campaign does not have any promotion.
                        this.noDataNode = null;
                        return trs;
                    }));
                }
            });

            this.grid = new this._gridClass(gridSettings, this.domNode);
        },

        startup: function() {
            this.inherited(arguments);

            this.own(aspect.around(this.grid, "renderRow", lang.hitch(this, this._aroundRenderRow)));

            when(this.getCurrentContext()).then(lang.hitch(this, function (currentContext) {
                this.grid.set("query", this._getQuery(currentContext.id));
            }));
        },

        _getQuery: function (parentId) {
            return {
                query: "getchildren",
                referenceId: parentId,
                typeIdentifiers: this.typeIdentifiers
            };
        },

        _aroundRenderRow: function (original) {
            // summary:
            //      Called 'around' the renderRow method in order to add a class which indicates the state of the row
            // tags:
            //      private

            return lang.hitch(this, function (item) {
                // Call original method
                var row = original.apply(this.grid, arguments);

                domClass.add(row, this.model.getItemClass(item));
                domClass.add(row, this.model.getItemStatusClass(item));

                return row;
            });
        },

        _modifyStoreToHandleDgridTree: function(){
            // summary:
            //      getChildren and mayHaveChildren are needed on the store
            //      for dgrids tree module to work.
            // tags:
            //      private
            var self = this;
            this.store = lang.mixin(this.store, {
                getChildren: function (parent, options) {
                    return this.query(self._getQuery(parent.contentLink), options);
                },
                mayHaveChildren: function (parent) {
                    // only campaigns have children
                    return TypeDescriptorManager.isBaseTypeIdentifier(parent.typeIdentifier, MarketingUtils.contentTypeIdentifier.salesCampaign);
                }
            });
        },

        fetchData: function(){
            // Refresh list after edit
            this.grid.refresh();
        }
    });
});