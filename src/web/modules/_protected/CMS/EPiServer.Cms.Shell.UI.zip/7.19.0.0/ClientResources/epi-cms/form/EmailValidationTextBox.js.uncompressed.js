﻿define("epi-cms/form/EmailValidationTextBox", [
    "dojo/_base/declare",
    "dojo/_base/lang",

    // CMS
    "epi-cms/form/EmailValidationBase"
], function (
    declare,
    lang,

    // CMS
    EmailValidationBase
    ) {

    return declare([EmailValidationBase], {
        // summary:
        //    Represents the email input textbox.
        // tags:
        //    internal

        postCreate: function () {
            this.inherited(arguments);

            lang.mixin(this.constraints, { allowCruft: true }); // allowCruft Allow address like <mailto:foo@yahoo.com>
        },

        _getValueAttr: function () {
            // make sure the hyper link has mailto: prefix
            var value = this.inherited(arguments);
            value = value ? lang.trim(value) : '';
            if (value && value.indexOf("mailto:") !== 0) {
                value = "mailto:" + value;
            }
            return value;
        },

        _setValueAttr: function (value) {
            value = value ? value.replace("mailto:", '') : '';
            this.inherited(arguments);
        }
    });
});