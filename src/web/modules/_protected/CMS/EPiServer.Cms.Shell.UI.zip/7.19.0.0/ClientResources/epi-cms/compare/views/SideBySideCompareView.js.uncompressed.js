define("epi-cms/compare/views/SideBySideCompareView", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",

    "epi/shell/widget/Iframe",
    "epi/shell/widget/_ModelBindingMixin",

    "epi-cms/contentediting/OnPageEditing",
    "epi-cms/compare/viewmodels/CompareViewModel",
    "epi-cms/compare/CompareToolbar"

],

function (
    declare,
    lang,
    topic,

    Iframe,
    _ModelBindingMixin,

    OnPageEditing,
    CompareViewModel,
    CompareToolbar
) {

    return declare([OnPageEditing, _ModelBindingMixin], {
        // summary:
        //		Side by side compare view.
        //
        // tags:
        //      internal

        // createOverlays: [Boolean]
        //      Indicate that the overlays should be created.
        createOverlays: true,

        modelBindingMap: {
            "leftVersionUri": ["leftVersionUri"],
            "rightVersionUrl": ["rightVersionUrl"]
        },

        _toolbar: null,
        _rightIframe: null,

        _isInitialized: null,

        destroy: function () {
            // summary:
            //		Destroy the widget.
            // tags:
            //		protected

            // Do not use own because Destroyable destroys owned things before destroy method is called.
            // As a result, we cannot remove the compare panes from edit layout.
            this._removeAndDestroyComparePanes();

            this.inherited(arguments);
        },

        onContentLinkSyncChange: function(oldContentLink, newContentLink) {
            // summary:
            //      Overridden to properly update the compare toolbar when the content link of the currently edited context changes

            this.model.set("contentLink", newContentLink);
        },

        onReadySetupEditMode: function () {
            // summary:
            //      Finish edit mode setting up.
            // description:
            //      Create editor wrappers for form widgets so it can update the model
            // tags:
            //      public, callback

            this.inherited(arguments);

            if (!this._isInitialized) {
                // Setup new stuffs
                this._setupCompareViewModel();
                this._setupComparePanes();
                this._isInitialized = true;
            } else {
                // Update view model with the new context
                if (this.viewModel.contentLink !== this.model.contentLink) {
                    this.model.set("languages", this.viewModel.contentData.existingLanguageBranches);
                    this.model.set("contentLink", this.viewModel.contentLink);
                    this.model.set("typeIdentifier", this.viewModel.contentData.typeIdentifier);
                }
            }
        },

        _setLeftVersionUriAttr: function (uri) {
            // tags:
            //      private

            if (uri && uri !== this.viewModel.contentData.uri) {
                // Request a context change
                topic.publish("/epi/shell/context/request", { uri: uri }, { sender: this });
            }
        },

        _setRightVersionUrlAttr: function (url) {
            // tags:
            //      private

            if (url) {
                this._rightIframe.load(url);
            }
        },

        _setupComparePanes: function () {
            // summary:
            //		Setup the edit form.
            // tags:
            //		private

            // Dojo puts an overflow hidden on the region containers which makes Firefox not display the scrollbar,
            // so we add the class epi-iframe--overflow to fix this
            this._rightIframe = new Iframe({
                region: (this.model.orientation === "vertical" ? "right" : "bottom"),
                layoutPriority: 100, // The top region panes' priority are from 0 to 99, the center panes' should be 100 or greater to keep the "headline" design.
                style: ( this.model.orientation === "vertical" ? "width: 50%;" : "height: 50%"),
                splitter: true,
                "class": "epi-iframe--overflow epi-editorViewport"
            });

            this._toolbar = new CompareToolbar({
                region: "top",
                splitter: false,
                model: this.model.compareToolbarViewModel
            });

            this.own(
                this._toolbar.on("versionInformationUpdated", lang.hitch(this, function () {
                    this.mainLayoutContainer.layout();
                }))
            );
            this.own(
                this._rightIframe.on("load", lang.hitch(this, this._onRightIframeLoad))
            );

            this.mainLayoutContainer.addChild(this._rightIframe);
            this.mainLayoutContainer.addChild(this._toolbar);
        },

        _onRightIframeLoad: function (url, triggeredExternally) {
            if (!!url && !triggeredExternally && url !== this.model.rightVersionUrl) {
                // Iframe is reloaded when user clicks on a link in preview iframe.

                // request a context change
                topic.publish("/epi/shell/context/request", { url: url }, {
                    sender: this,
                    forceContextChange: true,
                    suppressFailure: true
                });
            }
        },

        _setupCompareViewModel: function () {
            // summary:
            //      Setup model.
            // tags:
            //      private

            var model;

            this.own(model = new CompareViewModel({
                contentLink: this.viewModel.contentLink,
                typeIdentifier: this.viewModel.contentData.typeIdentifier,
                languages: this.viewModel.contentData.existingLanguageBranches
            }));

            this.set("model", model);
        },

        _removeAndDestroyComparePanes: function () {
            // summary:
            //		Check if a form exists so remove from edit layout and destroy it.
            // tags:
            //		private

            if (this._toolbar) {
                this.mainLayoutContainer.removeChild(this._toolbar);
                this._toolbar.destroy();
            }
            if (this._rightIframe) {
                this.mainLayoutContainer.removeChild(this._rightIframe);
                this._rightIframe.destroy();
            }
        }
    });
});
