﻿define("epi-cms/contentediting/ContentModelServerSync", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/Deferred",
    "dojo/_base/kernel",
    "dojo/_base/json",
    "dojo/_base/lang",
    "dojo/Stateful",

    "epi/datetime",
    "epi/string"
],

function (
    array,
    declare,
    Deferred,
    kernel,
    json,
    lang,
    Stateful,

    epiDateTime,
    epiString) {

    return declare([Stateful], {
        // tags:
        //    internal

        // _queue: [private] Array
        //      The queue of updates to send
        _queue: null,

        // _isSynchronizing: [private] Boolean
        //      Set to true while we're synchronizing
        _isSynchronizing: false,

        // hasPendingChanges: Boolean
        hasPendingChanges: false,

        // contentLink: String
        //      Reference to the content this sync service instance is saving changes to
        contentLink: null,

        // contentDataStore: RestStore
        //      Reference to the content data store
        contentDataStore: null,

        // processInterval: Number
        //      How often (in milliseconds) should we check the queue to see if there's any items to be synced
        processInterval: 200,

        // _processIntervalId: [private] Number
        //      Id of the interval to check queue, will only be set when save() has been called
        _processIntervalId: 0,

        _saveDeferred: null,

        _publish: false,

        constructor: function (params) {
            // summary:
            //      init array
            // tags:
            //      private

            lang.mixin(this, params);

            // init queue
            this._queue = [];
        },

        scheduleForSync: function (/*String*/propertyName, /*String|Object*/value) {
            // summary:
            //      Put property update in queue
            // propertyName:
            //      Name of the property
            // value:
            //      The value of the property
            // tags:
            //      public

            if (value === undefined) {
                return;
            }

            this.set("hasPendingChanges", true);
            value = epiDateTime.transformDate(value);

            var index = this._propertyIndexInQueue(propertyName);

            if (index < 0) {
                // add item to queue
                this._queue.push({
                    name: propertyName,
                    value: value
                });
            } else {
                // update item value
                this._queue[index].value = value;
            }
        },

        publishProperty: function (propertyName, value) {
            // summary:
            //      Sync a property value to the published version of the current content.
            // propertyName: String
            //      The property name.
            // value:
            //      The updated value.

            kernel.deprecated("epi-cms/contentediting/ContentModelServerSync::publishProperty", "use ::saveAndPublishProperty instead");

            return this.saveAndPublishProperty(propertyName, value);
        },

        saveAndPublishProperty: function (propertyName, value) {
            // summary:
            //      Sync a property value to the published version of the current content. The change is also synced to the current version.
            // propertyName: String
            //      The property name.
            // value:
            //      The updated value.

            //TODO: Shouldn't the this._published be pushed to the methods instead as private member?
            this._publish = true;
            this.scheduleForSync(propertyName, value);
            return this._synchronizeItem(true);
        },

        _propertyIndexInQueue: function (/*String*/propertyName) {

            var index = -1;

            // find item in queue
            array.some(this._queue, function (item, i) {
                if (item.name === propertyName) {
                    index = i;
                    return true;
                }
            });

            return index;
        },

        save: function () {
            // summary:
            //      Save updates to server
            // tags:
            //      public

            return this._startSynchronizeInterval();
        },

        _startSynchronizeInterval: function () {

            if (this._processIntervalId > 0) {
                return this._saveDeferred;
            }

            var fn = lang.hitch(this, function () {
                return this._synchronizeItem();
            });

            // trigger immediate first call
            var def = fn();

            // create interval
            if (this.processInterval >= 0) {
                this._processIntervalId = setInterval(fn, this.processInterval);
            }

            return def;
        },

        _stopSynchronizeInterval: function () {

            if (this._processIntervalId) {
                clearInterval(this._processIntervalId);
                this._processIntervalId = 0;
            }

        },

        _synchronizeItem: function () {
            // summary:
            //      Save updates to server
            // tags:
            //      private

            if (this._isSynchronizing) {
                return this._saveDeferred;
            }

            if (this._queue.length === 0) {
                return this._saveDeferred;
            }

            if (!this._saveDeferred) {
                this._saveDeferred = new Deferred();
            }

            this._isSynchronizing = true;

            //Copy the queue
            var items = this._queue;
            this._queue = [];

            var syncContentLink = this.contentLink;

            // Success callback
            var onSuccess = lang.hitch(this, function (result) {

                var successful = true;
                var defResult = {
                };

                if (result) {
                    //Convert the propery names to camel case
                    array.forEach(result.properties, lang.hitch(this, function (property) {
                        property.name = epiString.pascalToCamel(property.name);
                    }));

                    var savedLink = result.savedContentLink;

                    //Create def result object
                    defResult = lang.mixin({
                        successful: false,
                        contentLink: result.savedContentLink,
                        hasContentLinkChanged: result.savedContentLink && savedLink != this.contentLink
                    }, result);


                    if (savedLink && savedLink != this.contentLink) {
                        // If the server saved to another version than we anticipated
                        defResult.oldContentLink = this.contentLink;
                        this.contentLink = savedLink;
                    }

                } else {
                    successful = false;
                }

                this._isSynchronizing = false;

                if (this._queue.length === 0) {
                    this._stopSynchronizeInterval();

                    // reset flags
                    this.set("hasPendingChanges", false);

                    var def = this._saveDeferred;
                    this._saveDeferred = null;

                    if (successful) {
                        def.resolve(defResult);
                    } else {
                        def.reject({
                            contentLink: syncContentLink,
                            properties: items,
                            error: "Unexpected result returned from the server."
                        });
                    }
                }
            });

            // Failure callback
            var onError = lang.hitch(this, function (error) {

                var defResult = {
                    contentLink: syncContentLink,
                    properties: items,
                    error: error
                };

                this._isSynchronizing = false;

                if (this._queue.length === 0) {

                    var def = this._saveDeferred;
                    this._saveDeferred = null;

                    this._stopSynchronizeInterval();

                    this.set("hasPendingChanges", false);

                    def.reject(defResult);
                }
            });

            Deferred.when(this._saveProperties(items), onSuccess, onError);

            return this._saveDeferred;
        },

        pendingSync: function (propertyName) {
            // summary:
            //      Check if there is any pending synchronization for the property with propertyName
            //
            // propertyName: String
            //      The name of the property to check for
            //
            // returns:
            //      True if there are pending synchronizations, otherwise False
            // tags:
            //      public
            return this._propertyIndexInQueue(propertyName) !== -1;
        },

        _saveProperties: function (items) {
            // summary:
            //    Validate property value with server.
            //
            // propertyName: String
            //    The updated property name.
            //
            // propertyValue: String
            //    The property value.
            //
            // timestamp: String
            //    The client timestamp.
            //
            // returns:
            //	  A deferred
            //
            // tags:
            //    public

            var contentLink = this.contentLink;
            var properties = {};
            array.forEach(items, lang.hitch(this, function (item) {
                properties[item.name] = json.toJson(item.value);
            }));

            var patchData = {
                id: contentLink,
                properties: properties,
                publishChanges: this._publish
            };
            //reset publish state so we dont publish every time.
            this._publish = false;
            return this.contentDataStore.patch(patchData, { id: patchData.id });
        }
    });
});
